import {
  PointerSmoother,
  pickHand,
  type CalibrationProfile,
  type HandFeatureExtractor,
  type Handedness,
  type Instrument,
  type InstrumentFrame,
  cameraToView
} from '@instrument/domain';
import type { HandTracker } from '../tracking/HandTracker';

/** Something that receives every instrument frame, like the sound output or the page. */
export type FrameListener = (frame: InstrumentFrame) => void;
export type FrameErrorListener = (error: unknown) => void;

/** The video has data for the current frame (HTMLMediaElement.HAVE_CURRENT_DATA). */
const HAVE_CURRENT_DATA = 2;

/**
 * The real-time loop: on every new camera frame it runs the pipeline
 *   tracker → dominant hand → features → calibration → instrument rules
 * and hands the resulting frame to every listener (sound, screen).
 *
 * The loop doesn't know what the listeners do (Observer), so adding a new one,
 * like the game or a debug view, doesn't change this class.
 */
export class InstrumentLoop {
  private readonly listeners: FrameListener[] = [];
  private readonly errorListeners = new Set<FrameErrorListener>();
  private animationFrame: number | null = null;
  private lastVideoTime = -1;
  private readonly smoothing: PointerSmoother = new PointerSmoother();

  constructor(
    private readonly tracker: HandTracker,
    private readonly extractor: HandFeatureExtractor,
    private profile: CalibrationProfile,
    private readonly instrument: Instrument,
    private readonly video: HTMLVideoElement,
    private dominantHand: Handedness = 'Right'
  ) {}

  /** Changes which hand drives the instrument. Takes effect on the next processed frame. */
  setDominantHand(hand: Handedness): void {
    this.dominantHand = hand;
    this.smoothing.reset();  // reset smoothing, so the pointer doesn't jump
  }

  /** Changes the calibration profile. Takes effect on the next processed frame. */
  setCalibrationProfile(profile: CalibrationProfile): void {
    this.profile = profile;
  }
  
  /** Changes the sensitivity. Takes effect on the next processed frame. */
  setSensitivity(sensitivity: number): void {
    this.smoothing.setSensitivity(sensitivity);
  }

  /** Adds a listener. Returns a function that removes it. */
  subscribe(listener: FrameListener): () => void {
    this.listeners.push(listener);
    return () => {
      const index = this.listeners.indexOf(listener);
      if (index >= 0) this.listeners.splice(index, 1);
    };
  }

  /** Adds a listener for errors that stop real-time processing. */
  subscribeError(listener: FrameErrorListener): () => void {
    this.errorListeners.add(listener);
    return () => this.errorListeners.delete(listener);
  }

  /** Starts processing camera frames. Calling it again while running does nothing. */
  start(): void {
    if (this.animationFrame !== null) return;
    const step = (now: number) => {
      try {
        this.tick(now);
      } catch (error) {
        this.animationFrame = null;
        for (const listener of this.errorListeners) listener(error);
        return;
      }
      this.animationFrame = requestAnimationFrame(step);
    };
    this.animationFrame = requestAnimationFrame(step);
  }

  /** Stops processing camera frames. */
  stop(): void {
    if (this.animationFrame !== null) {
      cancelAnimationFrame(this.animationFrame);
      this.animationFrame = null;
    }
  }

  /** One step of the loop. Public so tests can run it without requestAnimationFrame. */
  tick(nowMs: number): void {
    // Screens refresh faster than cameras: only process a frame when the camera has a new one.
    if (this.video.readyState < HAVE_CURRENT_DATA || this.video.currentTime === this.lastVideoTime) {
      return;
    }
    this.lastVideoTime = this.video.currentTime;

    const hand = pickHand(this.tracker.detect(this.video, nowMs), this.dominantHand);
    //const raw = hand ? this.profile.apply(this.extractor.extract(hand)) : null;
   const features = hand ? this.extractor.extract(hand) : null;
const raw = features ? this.profile.apply({ ...features, pointer: this.toViewPoint(features.pointer) }) : null;
    if (!raw) this.smoothing.reset();
    const controls = raw ? { ...raw, pointer: this.smoothing.apply(raw.pointer) } : null;
    const frame = this.instrument.update(controls);
    for (const listener of this.listeners) {
      listener(frame);
    }
  }

  /** Moves the pointer from the camera image to what the player sees on the stage (the video is cropped by object-fit: cover). */
private toViewPoint(point: { x: number; y: number }): { x: number; y: number } {
  const { videoWidth, videoHeight, clientWidth, clientHeight } = this.video;
  // Before the first frame, the sizes are 0 (or missing in a test), so leave the point as it is.
  if (!(videoWidth > 0 && videoHeight > 0 && clientWidth > 0 && clientHeight > 0)) return point;
  return cameraToView(
    point,
    { width: videoWidth, height: videoHeight },
    { width: clientWidth, height: clientHeight },
  );
}
}
